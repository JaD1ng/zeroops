#!/bin/bash

# 服务停止脚本 - Floyd部署版本
set -e

# 设置环境变量
export SERVICE_NAME="${SERVICE_NAME:-metadata}"

# Floyd部署的标准路径
FLOYD_PACKAGE_DIR="/home/qboxserver/metadata/_package"

# 切换到Floyd包目录
cd "$FLOYD_PACKAGE_DIR" || { echo "错误: 无法切换到包目录 $FLOYD_PACKAGE_DIR"; exit 1; }

# 检查PID文件
if [ -f "metadata.pid" ]; then
    PID=$(cat metadata.pid)
    if kill -0 "$PID" 2>/dev/null; then
        echo "停止 $SERVICE_NAME 服务 (PID: $PID)..."
        kill "$PID"

        # 等待进程结束
        for i in {1..10}; do
            if ! kill -0 "$PID" 2>/dev/null; then
                echo "$SERVICE_NAME 服务已停止"
                rm -f metadata.pid
                exit 0
            fi
            sleep 1
        done

        # 强制杀死进程
        echo "强制停止 $SERVICE_NAME 服务..."
        kill -9 "$PID" 2>/dev/null || true
        rm -f metadata.pid
    else
        echo "$SERVICE_NAME 服务未运行"
        rm -f metadata.pid
    fi
else
    echo "$SERVICE_NAME 服务未运行"
fi
