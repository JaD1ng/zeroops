#!/bin/bash

# 服务启动脚本 - Floyd部署版本
set -e

# Floyd部署路径结构
# 服务目录: /home/qboxserver/metadata/
# 版本目录: /home/qboxserver/metadata/_fpkgs/版本号/
# 包目录: /home/qboxserver/metadata/_package/

# 设置环境变量
export SERVICE_NAME="${SERVICE_NAME:-metadata}"
export LOG_LEVEL="${LOG_LEVEL:-info}"

# Floyd部署的标准路径
FLOYD_SERVICE_DIR="/home/qboxserver/metadata"
FLOYD_PACKAGE_DIR="/home/qboxserver/metadata/_package"

# 切换到Floyd包目录
cd "$FLOYD_PACKAGE_DIR" || { echo "错误: 无法切换到包目录 $FLOYD_PACKAGE_DIR"; exit 1; }

# 从config.yaml读取端口
if [ -f "config.yaml" ]; then
    SERVICE_PORT=$(grep "port:" config.yaml | sed 's/.*port:[[:space:]]*\([0-9]*\).*/\1/')
    if [ -z "$SERVICE_PORT" ]; then
        SERVICE_PORT="8080"
    fi
    echo "从config.yaml读取到端口: $SERVICE_PORT"
else
    SERVICE_PORT="8080"
    echo "配置文件不存在，使用默认端口: $SERVICE_PORT"
fi
export SERVICE_PORT

# 检查配置文件
if [ ! -f "config.yaml" ]; then
    echo "错误: 配置文件 config.yaml 不存在"
    exit 1
fi

# 检查可执行文件
if [ ! -f "metadata-service" ]; then
    echo "错误: 可执行文件 metadata-service 不存在"
    exit 1
fi

# 设置权限
chmod +x "metadata-service"

# 启动服务
echo "启动 $SERVICE_NAME 服务..."
echo "工作目录: $FLOYD_PACKAGE_DIR"
echo "端口: $SERVICE_PORT"
echo "日志级别: $LOG_LEVEL"

# 后台运行服务
nohup ./metadata-service > metadata.log 2>&1 &

# 保存PID
echo $! > metadata.pid

echo "$SERVICE_NAME 服务已启动，PID: $(cat metadata.pid)"

